import math
a=[]
def accept():
	global m,n,f,a
	m=4
	n=12
	user=input("Enter the name of your file with itz extension:")
	f1=open(user,'r+',encoding="ISO-8859-1")
	f2=f1.read()
	a=list(f2)
def FIFO():
	m=4
	n=12
	print("Inside FIFO")
	f = -1
	page_faults=0
	page = []
	for i in range(m):
       		page.append(-1)
	for i in range(n):
		flag = 0
		for j in range(m):
			if(page[j]==a[i]):
				flag=1
				break
		if(flag==0):
			f=(f+1)%m
			page[f]=a[i]
			page_faults+=1
			print("\n->",a[i]),
			for j in range(m):
				if(page[j] != -1):
                	   		print(page[j])
				else:
                	    		print("-")
		else:
			print("\n -> No Page Fault",a[i])
	print("\n Total page faults:",page_faults)


def LFU():
	print("Inside LFU")
	m=4
	n=12
	x = 0
	page_faults = 0
	page = []
	time={}
	b=list(a)
	for i in range(m):
		page.append(-1)
	for i in a:
		time[i]=0
	for i in range(n):
		flag = 0
		for j in range(m):
			if(page[j] == a[i]):
				flag = 1
				time[a[i]]+=1
				break
		if(flag == 0):
			rpage = -1
			if(page[x] != -1):
				t=[]
				for k in page:
					t.append(time[k])
				minis=min(t)
				gpage=[]
				for k in page:
					if time[k] == minis:
						gpage.append(k)		
				maxi = -1
				flag = 0
				for k in gpage:
					for n in range(0,i):
						if(k == b[n]):
							if(maxi == -1):
								maxi = n
								rpage = k
							elif(n < maxi):
								maxi = n 
								rpage = k	
					flag=1
				if (flag == 1):
					b[maxi]=-1
					x = page.index(rpage)
			if(rpage != -1):
				time[rpage]=0
			page[x] = a[i]
			x=(x+1)%m
			time[a[i]]+=1
			page_faults+=1
			print("\n ->",a[i])
			for j in range(m):
				if(page[j] != -1):
					print(page[j])
				else:
					print("-")
		else:
			print("\n -> No Page Fault",a[i])
		
	print("\n Total page faults :",page_faults)
	print("\n Frequencies of pages: ",time)
	

def LRU():
	m=4
	n=12
	print("Inside LRU")
	x = 0
	page_faults = 0
	page = []
	for i in range(m):
		page.append(-1)
	for i in range(n):
		flag = 0
		for j in range(m):
			if(page[j] == a[i]):
				flag = 1
				break
		if flag == 0:
			if page[x] != -1:
				min = 999
				for k in range(m):
					flag = 0
					j =  i
					while j>=0:
						j-=1
						if(page[k] == a[j]):
							flag = 1
							break
					if (flag == 1 and min > j):
						min = j
						x=k
			page[x] = a[i]
			x=(x+1)%m
			page_faults+=1
			print("\n ->",a[i])
			for j in range(m):
				if(page[j] != -1):
					print (page[j])
				else:
					print("-")
		else:
			print("\n -> No Page Fault",a[i])
	print("\n Total page faults :",page_faults)
	


def OPTIMAL():
	print("Inside OPTIMAL")
	m=4
	n=12
	x = 0
	page_faults = 0
	page = []
	FREE = -1
	for i in range(m):
		page.append(FREE)
	for i in range(n):
		flag = 0
		for j in range(m):
			if(page[j] == a[i]):
				flag = 1
				break
		if flag == 0:
			faulted = False
			new_slot=FREE
			for q in range(m):
				if page[q] == FREE:
					faulted = True
					new_slot = q
			if not faulted:
				max_future = 0
				max_future_q = FREE
				for q in range(m):
					if page[q] != FREE:
						found = False
						for ii in range(i, n):
							if a[ii] == page[q]:
								found = True
								if ii > max_future:
									max_future = ii
									max_future_q = q
							break
						if not found:
							max_future_q = q
							break
				faulted = True
				new_slot = max_future_q
			page_faults += 1
			page[new_slot] = a[i]
			print("\n ->",a[i])
			for j in range(m):
				if(page[j] != FREE):
					print(page[j])
				else:
					print("-")
			else:
				print("\n -> No Page Fault",a[i])
	print("\n Total page faults :",page_faults)

def BF(blockSize, m, processSize, n):
	IF=0 
	print("*****BEST FIT*****")
	allocation = [-1] * n
	for i in range(n):
		bestIdx = -1
		for j in range(m): 
			if(blockSize[j] >= processSize[i]): 
				if bestIdx == -1:  
					bestIdx = j  
				elif(blockSize[bestIdx] > blockSize[j]):  
					bestIdx = j 
		if bestIdx != -1: 
			allocation[i] =bestIdx
			IF+=blockSize[bestIdx] -processSize[i] 
			blockSize[bestIdx] -=processSize[i]
	print("Process No. Process Size     Block no.") 
	for i in range(n): 
		print(i + 1,"            ",processSize[i],end = "                ")  
		if(allocation[i] != -1):  
			print(allocation[i] + 1)  
		else: 
			print("Not Allocated")
	print("INTERNAL FRAGMENTATION IS:",IF)

def FF(blockSize, m, processSize, n):
	IF=0
	allocate=[0]*n
	allocation = [-1] * n 
	for i in range(n): 
		for j in range(m):
			if(blockSize[j] >= processSize[i]):
					allocation[i] = j
					IF+=blockSize[j] - processSize[i]
					blockSize[j] -= processSize[i]
					break
		
	print(" Process No. Process Size      Block no.") 
	for i in range(n): 
		print("   ", i + 1, "         ", processSize[i],"         ", end = "     ")  
		if allocation[i] != -1:  
			print(allocation[i] + 1)  
		else: 
			print("Not Allocated")
	print("INTERNAL FRAGMENTATION IS:",IF)

def NF(blockSize, m, processSize, n):
	IF=0
	allocation =[-1] *n
	j=0
	for i in range(n):
		while(j<m):
			if((blockSize[j])>=(processSize[i])):
				allocation[i]=j
				IF+=blockSize[j]-processSize[i]
				blockSize[j]-=processSize[i]
				break
			j= (j + 1)
	print("Process No.  Process Size    Block no.")
	for i in range(n):
		print("  ",i + 1, "	", processSize[i],"      ",end = "	    ")
		if(allocation[i] != -1):
			print(allocation[i] + 1)
		else:
			print("Not Allocated")
	print("INTERNAL FRAGMENTATION IS:",IF)
	


def WF(blockSize, m, processSize, n):
	IF=0
	allocation = [-1] * n 
	for i in range(n):
		wstIdx = -1
		for j in range(m):
			if(blockSize[j] >= processSize[i]):
				if(wstIdx == -1):
					wstIdx = j
				elif blockSize[wstIdx] < blockSize[j]:  
					wstIdx = j
		if(wstIdx != -1):
			allocation[i] = wstIdx
			IF+=blockSize[wstIdx] - processSize[i]
			blockSize[wstIdx] -= processSize[i]
	print("Process No. Process Size Block no.") 
	for i in range(n): 
		print(i + 1, "       ",processSize[i], end = "    ")  
		if(allocation[i] != -1): 
			print(allocation[i] + 1)  
		else: 
			print("Not Allocated")
	print("INTERNAL FRAGMENTATION IS:",IF)


while True:
	print("*********************WELCOME***************************************")
	print("\n**************PAGE REPLACEMENT AND MEMORY ALLOCATION **********")
	print("\nMENU:")
	print("\n1.PAGE REPLACEMENT.")
	print("\n2.MEMORY ALLOCATION.")
	print("\n3.EXIT.")
	blockSize = [100, 500, 200, 300, 600]  
	processSize = [212, 417, 112, 426]  
	m = len(blockSize)
	n = len(processSize)  
	choice=int(input("Enter Your Choice:"))
	if(choice==1):
		print("\n************* PAGE REPLACEMENT ALGORITHM*************")
		print(" Menu:")
		print(" 1.FIFO.")
		print(" 2.LFU.")
		print(" 3.LRU.")
		print(" 4.Optimal.")
		print(" 5.Exit.")
		c=int(input("Select:"))
		if(c==1):
			accept()
			FIFO()
		if(c==2):
			accept()
			LFU()
		if(c==3):
			accept()
			LRU()
		if(c==4):
			accept()
			OPTIMAL()
		if(c==5):
			print ("BYEBYE!!!!!")
			break
	if(choice==2):
		print("\n********** MEMORY ALLOCATION STRATEGIES **********")
		print(" Menu:")
		print(" 1.BEST FIT.")
		print(" 2.FIRST FIT.")
		print(" 3.NEXT FIT.")
		print(" 4.WORST FIT.")
		print(" 5.Exit.")
		c=int(input("Select:"))
		if(c==1):
			BF(blockSize, m, processSize, n)
		if(c==2):
			FF(blockSize, m, processSize, n)
		if(c==3):
			NF(blockSize,m,processSize,n)
		if(c==4):
			WF(blockSize, m, processSize, n)
		if(c==5):
			print ("BYEBYE!!!!!")
			break	
	if(choice==3):
		print("BYEBYE!!!!!")
		break	


